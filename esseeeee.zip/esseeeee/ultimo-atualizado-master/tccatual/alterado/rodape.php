<style type="text/css">
    .rodape_index{
        width: 100%;
        height: 100px;
        margin-top: 10%;
        background: green;
        float: left;
    }
</style>

<section class="rodape_index">

    
</section>