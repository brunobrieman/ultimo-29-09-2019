 
<body>



  <?php
   include('cabecalho.php');
  ?>



    <style type="text/css">

  .cards_home{
    margin-top: 5%;
   width: 100%;

  }
      
  .card_home1{
    width: 20%;
    float: left;
   margin-left: 13%;
   
  }
  .card_home2{
    width: 20%;
    float: left;
    margin-left: 7%;
  }
  .card_home3{
    width: 20%;
    float: left;
  margin-left: 7%;
  }
  

      <style>
  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .hero-image {
    background-image: url("../img/fundo_home.jpg");
    
    background-position: center center;
    background-repeat: no-repeat;
    background-size: cover;
    position: relative; 
  
    padding: 20em;
  }

  </style>
  </head>
  <body>

  <div class="hero-image">
    <div class="hero-text">
  <center style = "margin-top: 20%;">
           <h1 class="animated fadeInLeftBig tituloIndex">Controle de acesso IFC</h1>
             <a href="usuario_cadastro.php"><button type="button" class="btn btn-outline-light my-2 my-sm-">Cadastre-se</button></a>
               <a href="login.php"><button type="button" class="btn btn-outline-light my-2 my-sm-">Entrar</button></a>
                 
      </div>
    </div>
  <center>
  <section class="cards_home">
     <div class="card_home1" >
    <img src="../img/pessoas.png" class="card-img-top" alt="...">
    <div class="card-body">
      <p class="card-text"><h5> Maior segurança à toda instituição </h5></p>
    </div>
  </div>

   <div class="card_home2">
    <img src="../img/cont.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <p class="card-text"><h5>Maior controle de entrada e saída</h5></p>
    </div>
  </div>
  <div class="card_home3">
    <img src="../img/comunicacao.png" class="card-img-top" alt="...">
    <div class="card-body">
      <p class="card-text"><h5>aqui vamos falar os beneficios do nosso sistema</h5></p>
    </div>
  </div>
  </section>
</center> 
</body>
</html>

<?php
include '../rodape.php';
?>