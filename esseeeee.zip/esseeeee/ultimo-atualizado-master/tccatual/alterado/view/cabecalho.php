<!DOCTYPE html>

<head>
	<title></title>
<script src="../js/jquery.js" ></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="../js/popper.min.js"  crossorigin="anonymous"></script>
<script src="../js/bootstrap.min.js"  crossorigin="anonymous"></script>
<link rel="stylesheet" href="../css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../css/trabalho.css">
<link rel="stylesheet" type="text/css" href="../css/animate.mim.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">



 
</head> 

<body>
  <header style="margin-bottom: 1%;">
  <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
    <a class="navbar-brand" href="#"><h5 style="color: green;">IFControll</h5></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarCollapse">
      <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="http://example.com" id="dropdown01" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Páginas</a>
            <div class="dropdown-menu" aria-labelledby="dropdown01">
              <a class="dropdown-item" href="../controllers/usuario.php?acao=index">Nupe</a>
              <a class="dropdown-item" href="cadastro_externo.php">Portaria</a>
              <a class="dropdown-item" href="pagina_discente.php">Aluno</a>
            </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="sobre.php">Sobre <span class="sr-only">(current)</span></a>
        </li>
      </ul>
      
    </div>
  </nav>
</header>
</body>
