<?php

session_start();
include "cabecalho.php";
if(isset($_POST['encerrarSession'])){
    unset($_SESSION['usuario']);
    header('Location: index.php');
}
 if(isset($_SESSION['usuario'])) {
?>

<div class="espaco"></div>
<hr>
<div class="container bootstrap snippet">
    
    <div class="row">
          
    <div class="col-sm-3"><!--left col-->
    <div class="text-center">
    <div class="col-sm-10"><h4><?php echo '<strong>'.$_SESSION['usuario'].'</strong>'?></h4></div>
    <form action="" method="POST">
        <button class="btn-primary btn" name="encerrarSession">encerrar sessão</button>
    </form>
      </div>
      
      <br>
      
               
         <div class="espaco"></div>
          
          <ul class="list-group">
           
            <a href =""><li class="list-group-item text-right"><span class="pull-left"><strong>turmas</strong></span></li></a>
            <a href =""><li class="list-group-item text-right"><span class="pull-left"><strong>lista de ocorrências</strong></span></li></a>
            <a href =""><li class="list-group-item text-right"><span class="pull-left"><strong>cadastro de ocorrências</strong></span></li></a>
            <li class="list-group-item text-right"><span class="pull-left"><strong>código nupe</strong></span></li>

          </ul> 
               
          <div class="panel panel-default"></div>
          
        </div>
    	<div class="col-sm-9">
        <h4>Listagem de Usuários cadastrados:</h4>

                    <a class="btn btn-success" href="../controllers/usuario.php?acao=cadastrar">Cadastrar novo</a>

                <table class="table" style="margin-top: 25px">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Nome</th>
                        <th scope="col">Email</th>
                        <th scope="col">Login</th>
                        
                    </tr>
                    </thead>
                    <tbody>

                        <?php foreach ($listaUsuarios as $usuario): ?>

                        <tr>
                            <th scope="row"><?= $usuario->cod_user; ?></th>
                            <td><?= $usuario->nome; ?></td>
                            <td><?= $usuario->email; ?></td>
                            <td><?= $usuario->login; ?></td>
                            <td>
                                <a class="btn btn-danger" href="http://localhost/tccatual/alterado/controllers/usuario.php?acao=editar&cod_user=<?= $usuario->cod_user ?>">editar</a>
                                <a class="btn btn-danger" href="http://localhost/tccatual/alterado/controllers/usuario.php?acao=excluir&cod_user=<?= $usuario->cod_user ?>">excluir</a>
                            </td>
                        </tr>
                        
                        <?php endforeach; ?>

                    </tbody>
                </table>
             

        </div><!--/col-9-->
    </div><!--/row-->
    <?php
        }else{
            header('Location:index.php');        
        }
    ?>
                