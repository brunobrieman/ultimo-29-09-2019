<?php

    session_start();

        if(isset($_POST['encerrarSession'])){
            unset($_SESSION['usuario']);
            header('Location: index.php');
        }
?> 
<?php if(isset($_SESSION['usuario'])) {?>
<?php include('head.php');?>

    <div class=" container">
        <div class="row mt-3 justify-content-md-center">
            <h1>eaeeee,<?php echo '<strong>'.$_SESSION['usuario'].'</strong>'?></h1>
        </div>

        <div class="row mt-3 justify-content-md-center">
                <form action="" method="POST">
                    <button class="btn-primary btn" name="encerrarSession">encerrar sessão</button>
                </form>
        </div>
    </div>
<?php 
}else{
        header('Location:index.php');
} ?>