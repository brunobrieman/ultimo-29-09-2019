<?php
include 'cabecalho.php';
?>

<style type="text/css">
	.capa_sobre{
		width: 100%;
		height: 200px;
		background: green;
		}
	.titu_sobre{
		font-style: 20px;
		color: white;


	}
	.inferior_sobre{
		width: 80%;
		margin-left: 10%;
		margin-top: 5%;
      padding: 5%;
       box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);

	
	}
</style>

<div class="sobre_fundo">
	<div class="capa_sobre">
		<center><h2 class="titu_sobre">IFcontroll</h2></center>
	</div>

	<div class="inferior_sobre">
		<center><h3>Quem somos</h3></center>
		
	

		<p class="text-justify">Percebendo a dificuldade das escolas brasileiras em relação ao controle de acesso a indivíduos colocando em risco toda a comunidade escolar,nosso sistema visa um maior controle da entrada e saída de alunos nos horários de aula e intervalos,  facilitando a comunicação entre responsáveis e a instituição proporcionando assim, mais segurança a discentes e servidores. O discente obrigatoriamente terá um cadastramento no sistema e com isso receberá documento em pdf com seus dados, se quiser entrar na instituição, só será deferida sua passagem com apresentação do documento já supracitado, e além disso a aprovação dos responsáveis institucionais para saída, a partir disto será registrado em lista todas as atividades e seus motivos,sendo isto exposto aos responsáveis. </p>    


		
	</div>
</div>

<?php
include '../rodape.php';
?>