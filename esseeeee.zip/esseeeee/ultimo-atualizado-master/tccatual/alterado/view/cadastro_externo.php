
<?php
 include "cabecalho.php";
?>

<body style="background: #8FBC8F">

        <br>
        <br>

    <div class="container"style="margin-top: 5%;">
                           
            <div class="col-md-6" style="
            background: white;
                margin-left: 25%;padding: 5%; box-shadow: 0 5px 8px 0 rgba(0, 0, 0, 0.2), 0 9px 26px 0 rgba(0, 0, 0, 0.19);">

            <center><h3 style="margin-bottom: 4%;">Cadastro de visitantes:
            Portaria</h3></center>

                    <form method="post" action="../controllers/usuario.php?acao=salvar">
                    <div class="form-group"/>
                        <label for="name">Nome</label>
                        <input name="nome" type="text" class="form-control" id="name"  placeholder="digite seu nome">
                    </div>
                    <div class="form-group">
                        <label for="email">CPF</label>
                        <input name="email" type="text" class="form-control" id="cpf"  placeholder="CPF do visitante">
                    </div>
                    
                    <label for="exampleFormControlTextarea1">Motivo:</label>
                    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
                     
                    <center><button type="submit" class="btn btn-success" style="width: 50%;border-radius: 10px; margin-top: 2%;">Submit</button></center>
                </form>
            </div>
        
</div>
</body>
</html>

<?php
include '../rodape.php';
?>